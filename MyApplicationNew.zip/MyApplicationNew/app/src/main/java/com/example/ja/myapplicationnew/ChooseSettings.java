package com.example.ja.myapplicationnew;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class ChooseSettings extends AppCompatActivity {
    private RadioGroup radioGroupWithCountries;
    private Button buttonSelect;
    private RadioButton radioButtonCountry;
    private static final String PREFERENCES_NAME = "userSettings";
    private static final String PREFERENCES_TEXT_FIELD = "countryName";
    private static final String PREFERENCES_WHICH_COUNTRY = "country";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_settings);

        addListenerOnButton();
    }


    public void addListenerOnButton() {
        radioGroupWithCountries = (RadioGroup) findViewById(R.id.radioGroupCountries);
        buttonSelect = (Button) findViewById(R.id.selectButton);

        buttonSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = radioGroupWithCountries.getCheckedRadioButtonId();
                radioButtonCountry = (RadioButton) findViewById(selectedId);

                Toast.makeText(ChooseSettings.this,
                        radioButtonCountry.getText(), Toast.LENGTH_SHORT).show();

                saveChosenSettings();
            }

        });
    }


    private void saveChosenSettings() {
        SharedPreferences preferences = getSharedPreferences(PREFERENCES_NAME, StartActivity.MODE_PRIVATE);

        SharedPreferences.Editor preferencesEditor = preferences.edit();
        String chosenCountry = radioButtonCountry.getText().toString();

        if(chosenCountry.equals("Argentina")){
            ImageView iv = (ImageView) findViewById(R.id.argentinaFlagId);
            iv.setTag(R.drawable.flag_argentina);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.putString(PREFERENCES_WHICH_COUNTRY, chosenCountry);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Australia")){
            ImageView iv = (ImageView) findViewById(R.id.australiaFlagId);
            iv.setTag(R.drawable.flag_australia);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Belgium")){
            ImageView iv = (ImageView) findViewById(R.id.belgiumFlagId);
            iv.setTag(R.drawable.flag_belgium);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Brazil")){
            ImageView iv = (ImageView) findViewById(R.id.brazilFlagId);
            iv.setTag(R.drawable.flag_brazil);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Croatia")){
            ImageView iv = (ImageView) findViewById(R.id.croatiaFlagId);
            iv.setTag(R.drawable.flag_croatia);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Colombia")){
            ImageView iv = (ImageView) findViewById(R.id.colombiaFlagId);
            iv.setTag(R.drawable.flag_colombia);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Costa Rica")){
            ImageView iv = (ImageView) findViewById(R.id.costaRicaFlagId);
            iv.setTag(R.drawable.flag_costarica);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Denmark")){
            ImageView iv = (ImageView) findViewById(R.id.denmarkFlagId);
            iv.setTag(R.drawable.flag_denmark);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Egypt")){
            ImageView iv = (ImageView) findViewById(R.id.egyptFlagId);
            iv.setTag(R.drawable.flag_egypt);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("England")){
            ImageView iv = (ImageView) findViewById(R.id.englandFlagId);
            iv.setTag(R.drawable.flag_england);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("France")){
            ImageView iv = (ImageView) findViewById(R.id.franceFlagId);
            iv.setTag(R.drawable.flag_france);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Germany")){
            ImageView iv = (ImageView) findViewById(R.id.germanyFlagId);
            iv.setTag(R.drawable.flag_germany);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Iceland")){
            ImageView iv = (ImageView) findViewById(R.id.icelandFlagId);
            iv.setTag(R.drawable.flag_iceland);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Iran")){
            ImageView iv = (ImageView) findViewById(R.id.iranFlagId);
            iv.setTag(R.drawable.flag_iran);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Japan")){
            ImageView iv = (ImageView) findViewById(R.id.japanFlagId);
            iv.setTag(R.drawable.flag_japan);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Mexico")){
            ImageView iv = (ImageView) findViewById(R.id.mexicoFlagId);
            iv.setTag(R.drawable.flag_mexico);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Morocco")){
            ImageView iv = (ImageView) findViewById(R.id.moroccoFlagId);
            iv.setTag(R.drawable.flag_morocco);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Nigeria")){
            ImageView iv = (ImageView) findViewById(R.id.nigeriaFlagId);
            iv.setTag(R.drawable.flag_nigeria);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Panama")){
            ImageView iv = (ImageView) findViewById(R.id.panamaFlagId);
            iv.setTag(R.drawable.flag_panama);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Peru")){
            ImageView iv = (ImageView) findViewById(R.id.peruFlagId);
            iv.setTag(R.drawable.flag_peru);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Poland")){
            ImageView iv = (ImageView) findViewById(R.id.polandFlagId);
            iv.setTag(R.drawable.flag_poland);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Portugal")){
            ImageView iv = (ImageView) findViewById(R.id.portugalFlagId);
            iv.setTag(R.drawable.flag_portugal);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Russia")){
            ImageView iv = (ImageView) findViewById(R.id.russiaFlagId);
            iv.setTag(R.drawable.flag_russia);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Saudi Arabia")){
            ImageView iv = (ImageView) findViewById(R.id.saudiarabiaFlagId);
            iv.setTag(R.drawable.flag_saudiarabia);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Senegal")){
            ImageView iv = (ImageView) findViewById(R.id.senegalFlagId);
            iv.setTag(R.drawable.flag_senegal);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Serbia")){
            ImageView iv = (ImageView) findViewById(R.id.serbiaFlagId);
            iv.setTag(R.drawable.flag_serbia);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("South Korea")){
            ImageView iv = (ImageView) findViewById(R.id.southkoreaFlagId);
            iv.setTag(R.drawable.flag_southkorea);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Spain")){
            ImageView iv = (ImageView) findViewById(R.id.spainFlagId);
            iv.setTag(R.drawable.flag_spain);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Sweden")){
            ImageView iv = (ImageView) findViewById(R.id.swedenlagId);
            iv.setTag(R.drawable.flag_sweden);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Switzerland")){
            ImageView iv = (ImageView) findViewById(R.id.switzerlandlagId);
            iv.setTag(R.drawable.flag_switzerland);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Tunisia")){
            ImageView iv = (ImageView) findViewById(R.id.tunisiaFlagId);
            iv.setTag(R.drawable.flag_tunisia);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else if(chosenCountry.equals("Uruguay")){
            ImageView iv = (ImageView) findViewById(R.id.uruguayFlagId);
            iv.setTag(R.drawable.flag_uruguay);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.apply();
        }
        else {
            chosenCountry = "None";
            ImageView iv = (ImageView) findViewById(R.id.earthFlagId);
            iv.setTag(R.drawable.flag_earth);

            Integer imageId = (Integer)iv.getTag();
            String imageIdString = String.valueOf(imageId);

            preferencesEditor.putString(PREFERENCES_TEXT_FIELD, imageIdString);
            preferencesEditor.putString(PREFERENCES_WHICH_COUNTRY, chosenCountry);
            preferencesEditor.apply();
        }

        startTemporaryActivity();
    }

    private void startTemporaryActivity(){
        Intent myIntent = new Intent(ChooseSettings.this, TemporaryActivity.class);
        ChooseSettings.this.startActivity(myIntent);
    }



}
