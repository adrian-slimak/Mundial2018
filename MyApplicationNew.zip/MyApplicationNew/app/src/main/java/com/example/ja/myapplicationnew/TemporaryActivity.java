package com.example.ja.myapplicationnew;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class TemporaryActivity extends AppCompatActivity {
    private static final String PREFERENCES_TEXT_FIELD = "countryName";
    private static final String PREFERENCES_NAME = "userSettings";
    private static final String PREFERENCES_WHICH_COUNTRY = "country";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temporary);

        restoreData();
    }


    private void restoreData() {
        SharedPreferences preferences = getSharedPreferences(PREFERENCES_NAME, StartActivity.MODE_PRIVATE);

        String textFromPreferences = preferences.getString(PREFERENCES_TEXT_FIELD, "");
        String whichCountry = preferences.getString(PREFERENCES_WHICH_COUNTRY, "");

        ImageView ivCountryFlag = (ImageView)findViewById(R.id.countryFlagId);
        int imageId = Integer.parseInt(textFromPreferences);
        ivCountryFlag.setImageResource(imageId);

    }

    /*
    private String checkIfUserSettingsAreSet(String userCountry){
        String result = userCountry;
        if(userCountry.equals("0")) result = "None";
        return result;
    }
     */



    @Override
    public void onBackPressed() {
        Intent myIntent = new Intent(TemporaryActivity.this, StartActivity.class);
        TemporaryActivity.this.startActivity(myIntent);
    }
}
